$(document).ready(function () {
  $('.card-body').each(function () {
    $(this).click(function () {
      let jenis = $(this).find('h5').attr('id');
      $('#suara').remove();
      $('#foto').remove();
      if (jenis == 'ayam') {
        $(this).prepend(`<img id="foto" src="images/ayam.png" class="card-img-top">`);
        $(this).find('.audio').append(`<audio src="audio/ayam.mp3" autoplay id="suara"></audio>`); } 
	else if (jenis == 'bebek') {
        $(this).prepend(`<img id="foto" src="images/bebek.png" class="card-img-top">`);
        $(this).find('.audio').append(`<audio src="audio/bebek.mp3" autoplay id="suara"></audio>`); }
	else if (jenis == 'burung') {
        $(this).prepend(`<img id="foto" src="images/burung.png" class="card-img-top">`);
        $(this).find('.audio').append(`<audio src="audio/burung.mp3" autoplay id="suara"></audio>`);} 
	else if (jenis == 'angsa') {
        $(this).prepend(`<img id="foto" src="images/angsa.png" class="card-img-top">`);
        $(this).find('.audio').append(`<audio src="audio/angsa.mp3" autoplay id="suara"></audio>`);}
	else if (jenis == 'sapi') {
        $(this).prepend(`<img id="foto" src="images/sapi.jpg" class="card-img-top">`);
        $(this).find('.audio').append(`<audio src="audio/sapi.mp3" autoplay id="suara"></audio>`);}
	else if (jenis == 'kambing') {
        $(this).prepend(`<img id="foto" src="images/kambing.jpg" class="card-img-top">`);
        $(this).find('.audio').append(`<audio src="audio/kambing.mp3" autoplay id="suara"></audio>`);} 
	else if (jenis == 'kuda') {
        $(this).prepend(`<img id="foto" src="images/kuda.png" class="card-img-top">`);
        $(this).find('.audio').append(`<audio src="audio/kuda.mp3" autoplay id="suara"></audio>`);}
        else if (jenis == 'kelinci') {
        $(this).prepend(`<img id="foto" src="images/kelinci.png" class="card-img-top">`);
        $(this).find('.audio').append(`<audio src="audio/kelinci.mp3" autoplay id="suara"></audio>`); }
	else if (jenis == 'badak') {
        $(this).prepend(`<img id="foto" src="images/badak.jpg" class="card-img-top">`);
        $(this).find('.audio').append(`<audio src="audio/badak.mp3" autoplay id="suara"></audio>`); } 
	else if (jenis== 'singa') {
        $(this).prepend(`<img id="foto" src="images/singa.png" class="card-img-top">`);
        $(this).find('.audio').append(`<audio src="audio/singa.mp3" autoplay id="suara"></audio>`);} 
	else if (jenis == 'ular') {
        $(this).prepend(`<img id="foto" src="images/ular.jpg" class="card-img-top">`);
        $(this).find('.audio').append(`<audio src="audio/ular.mp3" autoplay id="suara"></audio>`); }
	else {
        $(this).prepend(`<img id="foto" src="images/gorila.png" class="card-img-top">`);
        $(this).find('.audio').append(`<audio src="audio/gorila.mp3" autoplay id="suara"></audio>`);} 
    });
  });
});